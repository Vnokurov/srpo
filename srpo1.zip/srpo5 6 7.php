<?php

class People
{
    const TWO = 2;
    const  FO = 4;
    const SIX = self::FO + self::TWO;
    const SECOND_TEN = Animal::TEN;
    public $name;
    public $age;
    public $sex;

    public function __construct($name, $age, $sex)
    {
        $this->name = $name;
        $this->age = $age;
        $this->sex = $sex;

        echo "It`s called" . __METHOD__ . "<br>";
    }

    public function __destruct()
    {
        echo $this->name . " is destroyed";
    }
}

class Animal extends People
{
    const TEN = 10;
}

$people = new People("Arche", 20, "male");
echo 'const ' . People::SECOND_TEN . "<br>";

define('NAME', $people->name);
echo 'const '. NAME . "<br>";