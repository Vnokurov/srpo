<?php

class A
{
    public $a = 'A';

    private function __construct($name) {
        $this->name = $name;
        echo "It`s called "  . __METHOD__ . "<br>";
    }

    public function a($name)
    {
        return new A($name);
    }
}

class B extends A
{
    public $e = 'nam E';

    public function __construct()
    {
        echo "It`s called "  . __METHOD__ . "<br>";
       $a = A::a('Arche');
       var_dump($a);
    }
}

$b = new B("B");
