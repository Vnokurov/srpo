<?php

ini_set('pcre.recursion_limit', 5000000);
ini_set('max_execution_time', 100000000);

class People
{

    public $name;
    public $age;
    public $sex;

    public function __construct($name, $age, $sex)
    {
        static $level = 0;
        $level++;
        echo $level . '<br>';
        $this->name = $name;
        $this->age = $age;
        $this->sex = $sex;

        echo "It`s called" . __METHOD__ . "<br>";
    }

    public function __destruct()
    {
        echo $this->name . " is destroyed <br>";
        new People('Bim', 2, 'male');
    }

}

$people = new People("Arche", 20, "male");