<?php

class sam
{
    protected $id;
    protected $text;
    protected $coors;

    public function __construct($id, $text, array $coors)
    {
        $this->id = $id;
        $this->text = $text;
        $this->coors = $coors;
    }


    public function __call($method, $parameters)
    {
        if (in_array($method, array('x', 'y')))
        {
            return call_user_func_array(array($this, $method), $parameters);
        }
    }

    public function __get($property)
    {
        var_dump($this->$property);
    }
}

$task = new Sam(1, 'testing', array('x' => 10, 'y' => 5));
$task->print($task->coors);
