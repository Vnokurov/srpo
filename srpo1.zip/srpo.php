<?php

 class Slavian
 {
 

 	 function __construct()
 	{
 		echo "класс вызван через конструктор <br>";
 	}

 	public function slavian(){
 		echo "класс вызван через метод";
 	}
 }

 $slavian = new Slavian();
 $slavian->slavian();

?>