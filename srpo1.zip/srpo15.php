<?php

class A
{
    public $a = 'foo A';

    public function testA()
    {
        return 'Hi this is '.__METHOD__;
    }

    public function foo($param1, $param2)
    {
        return $param1 + $param2;
    }
}

class B extends A
{
    public $b = 'foo B';

    public function testB()
    {
        return 'Hi this is '.__METHOD__;
    }

    public function foo($param1, $param2)
    {
        return $param1 * $param2;
    }
}

$a = new A();
$b = new B();

echo $a->foo(10,5);
echo '<pre>';
echo$b->foo(10,10);