<?php
class sr2{

	public $name;
	public $lastname;
	
	function __construct ($name, $lastname){
		$this->name = $name;
		$this->lastname = $lastname;
		echo "Конструктор класса sr2 <br>";
	}

	function __destruct() {
		echo "Деструктор класса sr2";
	}
}
$examp = new sr2('Alex', 'Abramov');
var_dump($examp);
echo "<br>";
?>