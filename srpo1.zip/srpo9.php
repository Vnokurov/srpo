<?php

class Nasledsvoistv
{
    private $classes = array();

    protected function __construct()
    {
        if ( func_num_args() < 2 )
        {
            throw new Exception("Invalid arguments count. Must be 2 or more");
        }
        $classes = func_get_args();
        foreach ( $classes as $class )
        {
            if ( !is_string($class) || strlen($class) <= 0 )
            {
                throw new Exception("Invalid class name");
            }elseif ( !class_exists($class) )
            {
                throw new Exception("Class '{$class}' did not exsit");
            }elseif ( isset($this->classes[$class]) )
            {
                throw new Exception("Class '{$class}' must be refered only once in class declaration");
            }
            $this->classes[$class] = new $class;
        }
    }

    public function __get($key)
    {
        $objects = $this->getObjectsHaveProperty($key);
        $objectsCnt = count($objects);
        if ( $objectsCnt <= 0 )
        {
            throw new Exception("Invalid property '{$key}'.");
        }elseif ( $objectsCnt > 1 )
        {
            throw new Exception("Property '{$key}' have more than one class.");
        }
        return $objects[0]->$key;
    }

    public function __set($key, $value)
    {
        $objects = $this->getObjectsHaveProperty($key);
        $objectsCnt = count($objects);
        if ( $objectsCnt <= 0 )
        {
            return $this->$key = $value;
        }elseif ( $objectsCnt > 1 )
        {
            throw new Exception("Property '{$key}' have more than one class.");
        }
        return $objects[0]->$key = $value;
    }

    public function __call($string, $args)
    {
        $objects = $this->getObjectsImplementsMethod($string);
        $objectsCnt = count($objects);
        if ( $objectsCnt <= 0 )
        {
            throw new Exception("Method '{$string}' not implemented");
        }elseif ( $objectsCnt > 1 )
        {
            $classNames = array();
            foreach ( $objects as $object )
            {
                $classNames[] = get_class($object);
            }
            $object = implode(', ', $classNames);
            throw new Exception("Method '{$string}' implemented by classes {$object}. You must overload this method in child class");
        }else{
            $callAddress = array($objects[0], $string);
            $arguments = $args;
            return call_user_func_array($callAddress, $arguments);
        }
    }

    protected function getObjectsImplementsMethod($methodName)
    {
        $ret = array();
        foreach ( $this->classes as $class )
        {
            if ( method_exists($class, $methodName) )
            {
                $ret[] = $class;
            }
        }
        return $ret;
    }

    protected function getObjectsHaveProperty($propName)
    {
        $ret = array();
        foreach ( $this->classes as $class )
        {
            $properties = get_object_vars($class);
            if ( in_array($propName, array_keys($properties)) )
            {
                $ret[] = $class;
            }
        }
        return $ret;
    }
}
class A
{
    public $a = 'foo A';

    public function testA()
    {
        return 'Hi this is '.__METHOD__;
    }
    public function nam1()
    {
        return 0;
    }
}

class B
{
    public $b = 'nam B';

    public function testB()
    {
        return 'Hi this is '.__METHOD__;
    }

    public function nam1()
    {
        return 0;
    }
}

class nam1 extends Nasledsvoistv
{
    public $u = 'asd';
    function __construct()
    {
        Nasledsvoistv::__construct('A', 'B');
    }
}
try
{

    $object = new nam1();
    $ret = $object->testA();            // Вызывается A::testA()
    echo "A::testA returned: '{$ret}'";
    $ret = $object->testB();            // Вызывается B::testB()
    echo "B::testB returned: '{$ret}'" ;
    echo "A::a is '{$object->a}'<br>";    // Выводится A::a
    echo "B::b is '{$object->b}'<br>";    // Выводится B::b
    echo "A::a is '".($object->a = 'vam A')."'<br>";    // Меняется A::a
    echo "B::b is '".($object->b = 'vam B')."'<br>";    // Меняется B::b
    $object->nam1();

} catch ( Exception $e )
{
    echo "Sorry, failed because of ".$e->getMessage();
}